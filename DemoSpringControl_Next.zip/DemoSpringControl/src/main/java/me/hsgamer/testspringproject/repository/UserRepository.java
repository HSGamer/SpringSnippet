package me.hsgamer.testspringproject.repository;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import me.hsgamer.testspringproject.data.LoginRequest;
import me.hsgamer.testspringproject.data.User;

public class UserRepository {
	// key = username, value = User
	private static Map<String, User> userMap = new HashMap<>();
	
	public static boolean isUsernameAvailable(String username) {
		// kiem tra username co trong userMap hay khong
		return userMap.containsKey(username);
	}
	
	public static Optional<User> checkUser(LoginRequest loginRequest) {
		// lay user tu map
		User user = userMap.get(loginRequest.getUsername());
		
		// kiem tra xem user co trong userMap hay khong
		if (user == null)
			return Optional.empty(); // Tra ra cai cap bi trong
		
		// kiem tra password
		if (user.getPassword().equals(loginRequest.getPassword())) {
			return Optional.of(user); // Tra ra cai cap chua user
		} else {
			return Optional.empty();
		}
	}
	
	public static void addUser(User user) {
		userMap.put(user.getUsername(), user);
	}
}
