package me.hsgamer.testspringproject.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.validation.Valid;
import me.hsgamer.testspringproject.data.User;
import me.hsgamer.testspringproject.repository.UserRepository;

@Controller
@RequestMapping("/register")
public class RegisterController {
	@GetMapping({"/", "/index", ""})
	public String showRegister(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "register/index";
	}
	
	@PostMapping("/submit")
	public String submitRegister(@Valid @ModelAttribute("user") User user, BindingResult bindingResult) {
		// Kiem tra user co hop le hay khong
		if (bindingResult.hasErrors()) {
			return "register/index";
		}
		
		// Them user vao repository neu no khong co san
		if (!UserRepository.isUsernameAvailable(user.getUsername())) {
			UserRepository.addUser(user);
		}
		
		// Chuyen huong sang trang login
		return "redirect:/login";
	}
	
	@ModelAttribute("roles")
	public Map<String, String> getRoles() {
		Map<String, String> roles = new HashMap<>();
		roles.put("USER", "User");
		roles.put("MAN", "Manager");
		roles.put("AD", "Admin");
		return roles;
	}
	
	@ModelAttribute("hobbies")
	public List<String> getHobbies() {
		List<String> hobbies = new ArrayList<>();
		hobbies.add("Gaming");
		hobbies.add("Reading Books");
		hobbies.add("Listening to Music");
		return hobbies;
	}
}
