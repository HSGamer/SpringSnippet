package me.hsgamer.testspringproject.repository;

import java.util.HashMap;
import java.util.Map;

import me.hsgamer.testspringproject.data.LoginRequest;

public class UserRepository {
	// key = username, value = LoginRequest (user)
	private static Map<String, LoginRequest> userMap = new HashMap<>();
	
	static {
		LoginRequest user = new LoginRequest();
		user.setUsername("admin");
		user.setPassword("123456");
		addUser(user);
	}
	
	public static boolean isUsernameAvailable(String username) {
		// kiem tra username co trong userMap hay khong
		return userMap.containsKey(username);
	}
	
	public static boolean checkUser(LoginRequest loginRequest) {
		// lay user tu map
		LoginRequest requestFromMap = userMap.get(loginRequest.getUsername());
		
		// kiem tra xem user co trong userMap hay khong
		if (requestFromMap == null) return false;
		
		// kiem tra password
		return requestFromMap.getPassword().equals(loginRequest.getPassword());
	}
	
	public static void addUser(LoginRequest loginRequest) {
		userMap.put(loginRequest.getUsername(), loginRequest);
	}
}
