package me.hsgamer.testspringproject.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import me.hsgamer.testspringproject.data.LoginRequest;
import me.hsgamer.testspringproject.repository.UserRepository;

@Controller
@RequestMapping("/login")
public class LoginController {
	@GetMapping({ "/", "/index", "" })
	public String showLogin() {
		return "login/index";
	}

	@GetMapping(value = { "/", "/index", "" }, params = "fake")
	public String showFakeLogin() {
		return "login/indexAP";
	}

	@GetMapping("/show/{username}/{password}")
	@ResponseBody
	public LoginRequest showIdMessage(@PathVariable("username") String username,
			@PathVariable("password") String password) {
		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setPassword(password);
		loginRequest.setUsername(username);
		return loginRequest;
	}

	@PostMapping("/error")
	public String showError(@ModelAttribute("login") LoginRequest loginRequest) {
		return "login/error";
	}

	@PostMapping("/submit")
	public String submitLogin(@ModelAttribute("login") LoginRequest loginRequest) {
		// neu loginRequest co trong UserRepository
		if (UserRepository.checkUser(loginRequest)) {
			return "login/user";
		} else if (UserRepository.isUsernameAvailable(loginRequest.getUsername())) {
			// chuyen huong sang trang error
			return "forward:/login/error";
		} else {
			// chuyen huong sang trang Register
			return "redirect:/register";
		}
	}

	// Demo JSTL
	@ModelAttribute("messages")
	public List<String> getMessages() {
		return Arrays.asList(
				"Hello Class", 
				"This is Java 5", 
				"We hate Spring"
				);
	}
}
