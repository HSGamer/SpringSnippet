package me.hsgamer.testspringproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringControl2Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringControl2Application.class, args);
	}

}
