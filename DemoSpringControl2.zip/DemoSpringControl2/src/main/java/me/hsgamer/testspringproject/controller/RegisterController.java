package me.hsgamer.testspringproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import me.hsgamer.testspringproject.data.LoginRequest;
import me.hsgamer.testspringproject.repository.UserRepository;

@Controller
@RequestMapping("/register")
public class RegisterController {
	@GetMapping({"/", "/index", ""})
	public String showRegister(Model model) {
		LoginRequest user = new LoginRequest();
		model.addAttribute("user", user);
		return "register/index";
	}
	
	@PostMapping("/submit")
	public String submitRegister(@ModelAttribute("user") LoginRequest user) {
		// Them user vao repository neu no khong co san
		if (!UserRepository.isUsernameAvailable(user.getUsername())) {
			UserRepository.addUser(user);
		}
		
		// Chuyen huong sang trang login
		return "redirect:/login";
	}
}
