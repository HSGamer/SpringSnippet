package me.hsgamer.testspringproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringControl2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
